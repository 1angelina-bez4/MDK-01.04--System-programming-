﻿// 13.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>

int main()
{
    setlocale(LC_ALL, "Russian");

    printf("\n Задание 1\n");
    printf("Проверить истинность высказывания: Квадратное уравнение A·x^2 + B·x + C = 0\n");
    printf("с данными коэффициентами A (A не равно 0), B, C имеет ровно два вещественных корня\n");

    double A, B, C;
    double D;

m1:
    printf("Введите коэффициент A (A != 0): ");
    scanf_s("%lf", &A);

    if (A == 0)
    {
        printf("Ошибка! Коэффициент A не может быть равен 0.\n");
        goto m1;
    }

    printf("Введите коэффициент B: ");
    scanf_s("%lf", &B);
    printf("Введите коэффициент C: ");
    scanf_s("%lf", &C);

    D = B * B - 4 * A * C;

    printf("Уравнение: %.2lf*x^2 + %.2lf*x + %.2lf = 0\n", A, B, C);
    printf("Дискриминант D = %.2lf\n", D);

    if (D > 0)
    {
        printf("Высказывание ИСТИННО: уравнение имеет два различных вещественных корня.\n");
    }
    else
    {
        printf("Высказывание ЛОЖНО: уравнение НЕ имеет двух различных вещественных корней.\n");
        if (D == 0)
            printf("(Дискриминант равен 0 - один корень)\n");
        else
            printf("(Дискриминант меньше 0 - нет вещественных корней)\n");
    }

    printf("\n Задание 2\n");
    printf("Даны целые положительные числа A и B (A < B).\n");
    printf("Вывести все целые числа от A до B включительно; каждое число выводится столько раз, каково его значение.\n");

    int A1, B1;

m2:
    printf("Введите целое положительное число A (A < B): ");
    scanf_s("%d", &A1);
    printf("Введите целое положительное число B: ");
    scanf_s("%d", &B1);

    if (A1 <= 0 || B1 <= 0)
    {
        printf("Ошибка! Числа должны быть положительными.\n");
        goto m2;
    }

    if (A1 >= B1)
    {
        printf("Ошибка! Условие (A < B) не выполняется.\n");
        goto m2;
    }

    printf("Числа от %d до %d:\n", A1, B1);
    for (int i = A1; i <= B1; i++)
    {
        for (int j = 0; j < i; j++)
        {
            printf("%d ", i);
        }
        printf("\n");
    }

    printf("\n Задание 3 \n");
    printf("Подсчет знаков препинания в строке (точка, запятая, двоеточие, точка с запятой, восклицательный знак, вопросительный знак).\n");

    char str3[1024];
    int punctCount = 0;

    printf("Введите строку-предложение: ");
    fgets(str3, 1024, stdin); //fgets() сохраняет символ \n (Enter) в строке

    // Удаляем символ новой строки
    // Удаление последнего символа, если это \n
    int length = strlen(str3);
    if (length > 0 && str3[length - 1] == '\n')
        str3[length - 1] = 0;  // 0 то же самое что '\0'

    for (int i = 0; str3[i] != '\0'; i++)
    {
        if (str3[i] == '.' || str3[i] == ',' || str3[i] == ':' ||
            str3[i] == ';' || str3[i] == '!' || str3[i] == '?')
        {
            punctCount++;
        }
    }

    printf("Введенная строка: \"%s\"\n", str3);
    printf("Количество знаков препинания: %d\n", punctCount);

    printf("\n Задание 4 \n");
    printf("Поиск слова с максимальным количеством букв 'z'.\n");

    char str4[1024];
    char wordMaxZ[256] = "";
    char currentWord[256] = "";
    int maxZ = -1;
    int wordIndex = 0;
    int zCount = 0;

    printf("Введите строку-предложение на английском: ");
    scanf_s("%s1023", str3, 1024);

    int len4 = strlen(str4);
    if (len4 > 0 && str4[len4 - 1] == '\n')
        str4[len4 - 1] = '\0';

    // Разбор строки вручную (без strtok)
    for (int i = 0; i <= len4; i++)
    {
        // Если достигли конца слова или строки
        if (str4[i] == ' ' || str4[i] == '\t' || str4[i] == '\0')
        {
            if (wordIndex > 0) // Если есть слово
            {
                currentWord[wordIndex] = '\0';

                // Подсчет 'z' в слове
                zCount = 0;
                for (int j = 0; currentWord[j] != '\0'; j++)
                {
                    if (currentWord[j] == 'z' || currentWord[j] == 'Z')
                        zCount++;
                }

                // Сравнение с максимумом
                if (zCount > maxZ)
                {
                    maxZ = zCount;
                    int k;
                    for (k = 0; currentWord[k] != '\0'; k++) {
                        wordMaxZ[k] = currentWord[k];
                    }
                    wordMaxZ[k] = '\0';
                }

                wordIndex = 0; // Сброс для следующего слова
            }
        }
        else
        {
            currentWord[wordIndex++] = str4[i];
        }
    }
    printf("Исходное предложение: \"%s\"\n", str4);
    if (maxZ > 0)
    {
        printf("Слово с максимальным количеством 'z' (встречается %d раз): \"%s\"\n", maxZ, wordMaxZ);
    }
    else if (maxZ == 0)
    {
        printf("В предложении нет слов, содержащих букву 'z'.\n");
    }
    else
    {
        printf("В предложении нет слов.\n");
    }

    printf("\n Задание 5 \n");
    printf("Подсчет слов, содержащих хотя бы одну цифру.\n");

    char str5[1024];
    int digitWordCount = 0;
    int hasDigit = 0;

    printf("Введите строку-предложение на английском: ");
    scanf_s("%s1023", str5, 1024);

   int len = strlen(str5);
    if (len > 0 && str5[len - 1] == '\n')
        str5[len - 1] = '\0';

    wordIndex = 0;
    hasDigit = 0;

    for (int i = 0; i <= len; i++)
    {
        // Если достигли конца слова или строки
        if (str5[i] == ' ' || str5[i] == '\t' || str5[i] == '\0')
        {
            if (wordIndex > 0) // Если есть слово
            {
                if (hasDigit)
                {
                    digitWordCount++;
                }

                wordIndex = 0; // Сброс для следующего слова
                hasDigit = 0;
            }
        }
        else
        {
            // Проверяем, является ли символ цифрой
            if (str5[i] >= '0' && str5[i] <= '9')
            {
                hasDigit = 1;
            }
            wordIndex++;
        }
    }

    printf("Исходное предложение: \"%s\"\n", str5);
    printf("Количество слов, содержащих хотя бы одну цифру: %d\n", digitWordCount);

}
